# Students

- Responsible of the codes: SARETE
- Responsible of the documentation: CREPIN
- Responsible of the unit tests: JANIN

# Players

*Please write here a few lines on the players you wrote.*
*Precise which choices you made, and why.*
*If you chose to create some functions, which ones and why?*
*What is the complexity of these functions?*
*Did you use defensive programming? if so, where and how?*

-Player Greedy:

The player we implemented is a greedy algorithm designed to navigate a maze and collect all the "cheeses" efficiently by choosing the nearest cheese at each step.

We chose a greedy strategy because it simplifies the problem and provides a reasonable solution for traversing the maze. To implement this, we first use a modified Dijkstra’s algorithm to precompute distances between the player and all cheeses, building a metagraph. The metagraph simplifies the maze by representing only key points of interest (player and cheeses) and the shortest paths between them. We used a MinHeap structure for efficient priority queue operations during Dijkstra’s traversal.

-The goal of the metahraph function is to set up a metagraph of the position of each cheese and the distance of the shortest path between each cheese and the current position of the rats 

-The traversal function performs Dijkstra's algorithm, returning two dictionaries:
->explored_vertices contains the shortest distances from the source to other nodes.
->routing_table stores the parent node for each vertex, used to reconstruct paths. 

-The find_route function uses this routing table to trace a path from the player to the cheese, reversing it for ease of use. 

-The greedy function determines the order of cheese collection by iteratively selecting the nearest unvisited cheese

-The find_routes function compiles the complete path based on these routing tables and the greedy order.

The complexity of traversal is O((V+E)logV), find_route has a complexity of 𝑂(𝑉) and the greedy order computation runs in O(V**2) where V is the number of vertices and E the edges in the maze.

We applied defensive programming in different codes. In the traversal function, we check if the list of cheeses is empty at the start, returning empty dictionaries to prevent unnecessary computations. In the get_metagraph function, we validate vertices before adding edges, ensuring the graph structure remains consistent. Additionally, in find_routes, we handle cases where a direct routing table between two points does not exist by reversing the path if necessary. These checks prevent runtime errors and make the player resilient to unexpected input or edge cases.

-PLayer GreedyEachCheese: 

The player we implemented is a greedy_each_cheese algorithm designed to navigate a maze and collect all the "cheeses" efficiently by choosing the nearest cheese at each step. Indeed, this algorithm recalculate the nearest cheese after reaching the position of this nearest cheese even if during this process the cheese was eaten by the opponent. 

The strategy was the same as for the greedy but we recalculate the metagraph after reaching each cheese

Most of the functions are the same except:

-update_metagraph: we calculate the metagraph after reaching each so we have to update the metagraph and it is the role of this function 

-greedy was modified: we return the next closest cheese and not the list of cheese to visit

The complexity of :
-get_metagraph is O(V**2+E)
-update_metagraph is O(V+E)
-greedy is O(V)
-traversal is O((V+E)log(V))
-find_route is O(V)
-find_routes is 0(N.V)
where V is the number of vertices and E the edges in the maze and N is the number of points to visit.

We didn't use defensive programming

-Player GreedyEachTurn:

The player we implemented is a greedy_each_cheese algorithm designed to navigate a maze and collect all the "cheeses" efficiently by choosing the nearest cheese at each step. 
Indeed, this algorithm recalculate the nearest cheese after each turn if the targeted cheese disapears. 

We only changed the 'turn' method when the metagraph is recalculated

The complexity of :
-get_metagraph is O(V**2+E)
-update_metagraph is O(V+E)
-greedy is O(V)
-traversal is O((V+E)log(V))
-find_route is O(V)
-find_routes is 0(N.V)
where V is the number of vertices and E the edges in the maze and N is the number of points to visit.

We didn't use defensive programming

# Games

*Please write here a few lines on the game scripts you created.*
*What are they made for?*
*Did you change some game parameters? If so, which ones and why?*

-We implemented five games versions: 
-> visualize_Greedy
-> visualize_GreedyEachCheese
-> visualize_GreedyEachTurn
-> compare_exhaustive_greedy
-> match_Greedy_GreedyEachTurn

- All theses scripts are designed to initialize a game with a specific configuration, add 
respectively the Greedy player, the GreedyEachCheese player and the GreedEachTurn player to the game, and then run the game using the player to visualize 
and collect results.
The compare game file is aimed at comparing the basic greedy algorithm to the Exhaustive one, comparing both speed in processing time and number of turns needed to catch all cheeses. 
It shows that the greedy algorithm is only a bit less effective in terms of turns but way faster than the exhaustive one.\

The match game file compares the different greedy algorithms in a 1 vs 1 game. We answered the differents question of the practical activity there.


# Unit tests

*Please write here a few lines on the tests you designed.*
*What are they testing?*
*Do you test some error use cases?*
*Are there some missing tests you would have liked to make?*

For the Greedy player:

-test_get_metagraph: this function tests that the metagraph return by the function get-metagraph is correct with an easy case 

-test_greedy: this function tests that greedy algorithm return a correct list of cheese on a easy example. This list of cheese must be created by choosing the closest neighbor at each vertex. 

For the GreedyEachCheese player:

-test_get_metagraph: this function tests that the metagraph return by the function get-metagraph is correct with an easy case

-test_greedy: this function tests that greedy algorithm return the correct cheese on a easy example. This cheese must be the closest vertex of the current one. 

For the GreedyEachCheese player:

-test_get_metagraph: this function tests that the metagraph return by the function get-metagraph is correct with an easy case

-test_greedy: this function tests that greedy algorithm return the correct cheese on a easy example. This cheese must be the closest vertex of the current one. 

-test_greedy_eaten_cheese: this function checks on an example where the cheese is eaten before being reached if the algorithm works correctly. It means the algorithm changes the next cheese wanted. 





# Utils

*Did you provide anything in the `utils` directory?*
*What are those files?*

We didn't add new 'utils' 

However we used the MinHeap already implemented:

In the 'utils' directory, we put a MinHeap file. It is an implementation of a MeanHeap for efficient priority handling.

The file contain a MinHeap Class. 

This MinHeap Class creates a MinHeap data structure, which is crucial for pathfinding algorithms that require efficient access to the smallest (or minimum-cost) element.

It provides a method to add or replace elements called add_or_replace based on their priority values (replace the element if its weight is lower) and  a method called remove to remove the element with the lowest priority (the element with the lowest weight).

The MinHeap is implemented as a list-based structure, with custom methods to maintain the heap properties without using the standard heapq library


# Documentation

*Anything to say regarding the documentation?*

<write here>


# Others

*If you had to answer particular questions in the practical session, write your answers here*
*Did you make some interesting analyses?*
*Does your code have particular dependencies we should install ?*
*Anything else to add?*

<write here>