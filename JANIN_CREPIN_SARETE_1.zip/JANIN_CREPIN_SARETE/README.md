# Students

- Responsible of the codes: CREPIN
- Responsible of the documentation: JANIN
- Responsible of the unit tests: SARETE



# Players

*Please write here a few lines on the players you wrote.*
*Precise which choices you made, and why.*
*If you chose to create some functions, which ones and why?*
*What is the complexity of these functions?*
*Did you use defensive programming? if so, where and how?*

The player we implemented is a simple Dijkstra-based algorithm 
that navigates a maze to reach a target destination, the cheese,
by finding the shortest path.

We chose Dijkstra’s algorithm because it guarantees the shortest
path in a weighted graph with non-negative weights, which is crucial
for efficient maze navigation. To implement this method, we chose a 
MinHeap structure that is implemented in utils. This structure allows us
to have always the vertex with smallest path thanks to the method remove.

We creates a function traversal and a function find_route. 
The traversal function performs Dijkstra’s traversal on the maze graph, starting 
from the player’s position. 
It returns two dictionaries:
    -explored_vertices: that stores distances from the start position to each node.
    -routing_table: holds the parent of each node, which helps trace the shortest path 
    back from the target to the source
The find_route function reconstructs the path from the player’s starting position to the
cheese using the routing_table. It traces backward from the cheese to the start, then reverses
the list for easy use.


The complexity of traversal is O((V+E)logV) and the complexity of find_route is O(V) where 
V is the number of vertices (maze nodes) and E is the number of edges (connections)

We didn't use defensive programming 


# Games

*Please write here a few lines on the game scripts you created.*
*What are they made for?*
*Did you change some game parameters? If so, which ones and why?*

The script is designed to initialize a game with a specific configuration, add 
the Dijkstra player to the game, and then run the game using Dijkstra player to visualize 
and collect results.

Game parameters:
* mud_percentage: We set it to 20%, we alos tried 0% and other percentages to see how our algorithm reacts
* nb_cheese: We set it to 1, meaning there is only a single cheese as the target. 
* random_seed: We set it to 42 to ensure consistency in maze layout and obstacles across runs. Using a fixed seed allows for replicable results, which is essential for debugging and testing changes to the Dijkstra player.
* trace_length: This was set to 1000, limiting the number of moves or actions recorded in the game trace. This parameter ensures that the game does not run indefinitely.


# Unit tests

*Please write here a few lines on the tests you designed.*
*What are they testing?*
*Do you test some error use cases?*
*Are there some missing tests you would have liked to make?*

We created two unit test files, one for the MinHeap structure and another for the Dijkstra player.
The minheap tests:
* adding new items to empty heap
* poping an item
* replacing an already existing item
* not changing an item if its value is smaller than the new one
* test str and int as item key

The test file for Dijkstra is a copy of the test file for the BFS since the Disjkstra traversal is appliable to all BFS test.
We added a hand-made graph to the specific test in order to verify the behavior of the traversal in the case of a weighted graph with loops.

# Utils

*Did you provide anything in the `utils` directory?*
*What are those files?*

In the 'utils' directory, we put a MinHeap file. It is an implementation of a MeanHeap that is be used with Dijkstra’s algorithm for efficient priority handling.

The file contain a MinHeap Class. 

This MinHeap Class creates a MinHeap data structure, which is crucial for pathfinding algorithms that require efficient access to the smallest (or minimum-cost) element so crucial for Dijkstra’s algorithm.

It provides a method to add or replace elements called add_or_replace based on their priority values (replace the element if its weight is lower) and  a method called remove to remove the element with the lowest priority (the element with the lowest weight).

The MinHeap is implemented as a list-based structure, with custom methods to maintain the heap properties without using the standard heapq library


# Documentation

*Anything to say regarding the documentation?*

<write here>



# Others

*If you had to answer particular questions in the practical session, write your answers here*
*Did you make some interesting analyses?*
*Does your code have particular dependencies we should install ?*
*Anything else to add?*

<write here>